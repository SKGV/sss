//
//  SoapParser.swift
//  ETN
//
//  Created by Varun Raj on 27/01/16.
//  Copyright © 2016 Varun Raj. All rights reserved.
//

import Foundation

class SoapParser: NSObject {
    
    func loginResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            print("RootValue"+xmlDoc.root["soap:Body"]["PingResponse"]["PingResult"].stringValue)
            
            let value = xmlDoc.root["soap:Body"]["PingResponse"]["PingResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func getDataResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //            print("RootValue"+xmlDoc.root["soap:Body"]["PingResponse"]["PingResult"].stringValue)
            //
            let value = xmlDoc.root["soap:Body"]["GetDataResponse"]["GetDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func getIncidentsResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //            print("RootValue"+xmlDoc.root["soap:Body"]["PingResponse"]["PingResult"].stringValue)
            //
            //            let value = xmlDoc.root["soap:Body"]["GetIncidentsResponse"]["GetIncidentsResult"]["string"].all
            
            let incidentArray:NSMutableArray = []
            
            if let values = xmlDoc.root["soap:Body"]["GetIncidentsResponse"]["GetIncidentsResult"]["string"].all {
                for incidentValue in values {
                    if let incident = incidentValue.value {
                        print(incident)
                        incidentArray.addObject(incident)
                    }
                }
            }
            
            return incidentArray
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func getLocationsResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //            print("RootValue"+xmlDoc.root["soap:Body"]["PingResponse"]["PingResult"].stringValue)
            //
            let value = xmlDoc.root["soap:Body"]["GetDataResponse"]["GetDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func getFiltersDataResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //            print("RootValue"+xmlDoc.root["soap:Body"]["PingResponse"]["PingResult"].stringValue)
            //
            let value = xmlDoc.root["soap:Body"]["GetFilteredDataResponse"]["GetFilteredDataResult"].stringValue
            
//            let value = xmlDoc.root["soap:Body"]["GetDataByDataIdResponse"]["GetDataByDataIdResult"].stringValue

            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func getVechicalsResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //            print("RootValue"+xmlDoc.root["soap:Body"]["PingResponse"]["PingResult"].stringValue)
            //
            let value = xmlDoc.root["soap:Body"]["GetDataResponse"]["GetDataResult"].stringValue
            
            return value
            
            //            let vechicalArray:NSMutableArray = []
            //
            //            if let values = xmlDoc.root["soap:Body"]["GetIncidentsResponse"]["GetIncidentsResult"]["data"]["record"].all {
            //                for incidentValue in values {
            //                    if let incident = incidentValue.value {
            //                        print(incident)
            //                        vechicalArray.addObject(incident)
            //                    }
            //                }
            //            }
            //
            //            return vechicalArray
            
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func parseVechicleData(stringData:String) -> AnyObject {
        
        do {
            
            let data = stringData.dataUsingEncoding(NSUTF8StringEncoding);
            
            let xmlDoc = try AEXMLDocument(xmlData: data!)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            let value = xmlDoc.root["data"].stringValue
            
            return value
            
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func addLocationResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["AddDataResponse"]["AddDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func updateLocationResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["UpdateDataResponse"]["UpdateDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    
    func addVehicleResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["AddDataResponse"]["AddDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func updateVehicleResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["UpdateDataResponse"]["UpdateDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    
    func addPeopleResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["AddRelatedDataResponse"]["AddRelatedDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func addAssetResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["AddRelatedDataResponse"]["AddRelatedDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func getAssetPetResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["AddRelatedDataResponse"]["AddRelatedDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func getRosterResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["GetFilteredDataResponse"]["GetFilteredDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    // MARK: -  Scan Batch People
    
    func getFilterPeopleToLocationResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //            print("RootValue"+xmlDoc.root["soap:Body"]["PingResponse"]["PingResult"].stringValue)
            //
//            let value = xmlDoc.root["soap:Body"]["GetDataResponse"]["GetDataResult"].stringValue
            let value = xmlDoc.root["soap:Body"]["GetFilteredDataResponse"]["GetFilteredDataResult"].stringValue

            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func updateBatchDataResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            let value = xmlDoc.root["soap:Body"]["UpdateDataBatchResponse"]["UpdateDataBatchResult"]["int"].stringValue
            
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }

    
    func addDataResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["AddDataResponse"]["AddDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }

    func getDataForDataIDResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["GetDataByDataIdResponse"]["GetDataByDataIdResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    
    func updateDataForDataIDResponseParser(data: NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            // prints the same XML structure as original
            print("Xml Value"+xmlDoc.xmlString)
            
            //
            let value = xmlDoc.root["soap:Body"]["UpdateDataResponse"]["UpdateDataResult"].stringValue
            
            return value
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }


    
    func errorResponse(data:NSData) -> AnyObject {
        
        do {
            
            let xmlDoc = try AEXMLDocument(xmlData: data)
            
            print("Xml Value"+xmlDoc.xmlString)
            
            var value:String = ""
            if (xmlDoc.root["soap:Body"].children[0].name == "soap:Fault") {
                value = xmlDoc.root["soap:Body"]["soap:Fault"]["detail"]["description"].stringValue
                
                return value
            } else {
                
                return value
                
            }
            //
            
        } catch {
            print("Parse Error")
            return "error"
        }
        
    }
    

    
    
    
}