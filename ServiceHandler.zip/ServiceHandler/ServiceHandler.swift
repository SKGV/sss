//
//  ServiceHandler.swift
//  ETN
//
//  Created by Varun Raj on 24/01/16.
//  Copyright © 2016 Varun Raj. All rights reserved.
//

import Foundation

class ServiceHandler: NSObject, NSURLConnectionDelegate, NSXMLParserDelegate {
    
    func sendServiceRequest(urlString : String, message: String,  handler: serviceHandlerDelegate, servicename: String = "") {
        
        let soapMessage = message
        print(urlString)
        let url = NSURL(string:urlString)
        
        let request = NSMutableURLRequest(URL: url!)
        
        let msgLength = String(soapMessage.characters.count)
        
        //        request.addValue("application/json", forHTTPHeaderField: "Accept")
        //        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("utf-8", forHTTPHeaderField: "Content-Encoding")
        request.addValue("application/soap+xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        //        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        request.HTTPMethod = "POST"
        request.HTTPBody = soapMessage.dataUsingEncoding(NSUTF8StringEncoding)
        request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
        
        
        let session = NSURLSession.sharedSession()
        
        let task = session.dataTaskWithRequest(request) {
            (
            let data, let response, let error) in
            
            guard let _:NSData = data, let _:NSURLResponse = response  where error == nil else {
                
                print(error)
                print("error")
                
                if(handler.error != nil) {
                    handler.error!(error!)
                }
                return
            }
            
            let dataString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print(dataString)
            
            
            if(servicename == SERVICES.ping){
                handler.pingSuccessful!(data!)
            } else if (servicename == SERVICES.getServer){
                handler.getDataSuccessful!(data!)
            } else if (servicename == SERVICES.getIncidents){
                handler.getIncidentsSuccessful!(data!)
            } else if (servicename == SERVICES.getRosterData){
                handler.getRosterWithDataIDSuccessful!(data!)
            } else if (servicename == SERVICES.getFilterDataForPeople){
                handler.getFilterDataForPeopleSuccessful!(data!)
            } else if (servicename == SERVICES.getFilterDataForAsset){
                handler.getFilterDataForAssetSuccessful!(data!)
            } else if (servicename == SERVICES.getFilterDataForPet){
                handler.getFilterDataForPetSuccessful!(data!)
            } else if (servicename == SERVICES.updateBatchPeopleToLocation) {
                handler.updateBatchPeopleToLocationSuccessful!(data!)
            } else if (servicename == SERVICES.getMicroBlinkKey) {
                handler.getMicroBlinkKeySuccessful!(data!)
            } else if (servicename == SERVICES.getMicroBlickDataForID) {
                handler.getDataForDataIDSuccessful!(data!)
            } else if (servicename == SERVICES.updateMicroBlinkDataForID) {
                handler.updateMicroBlinkDataForDataIDSuccessful!(data!)
            } else if(urlString == SERVICE_URL+SERVICES.ping) {
                handler.pingSuccessful!(data!)
            } else if servicename == SERVICES.getLocations {
                handler.getLocationsSuccessful!(data!)
            } else if servicename == SERVICES.getVehicals {
                handler.getVehicalsSuccessful!(data!)
            } else if servicename == SERVICES.getData {
                handler.getDataSuccessful!(data!)
            } else if servicename == SERVICES.getIncidents {
                handler.getIncidentsSuccessful!(data!)
            } else if servicename == SERVICES.addLocation {
                handler.addLocationsSuccessful!(data!)
            } else if servicename == SERVICES.addVehicle {
                handler.addVehicleSuccessful!(data!)
            } else if servicename == SERVICES.updateLocation {
                handler.addLocationsSuccessful!(data!)
            } else if servicename == SERVICES.updateVehicle {
                handler.addVehicleSuccessful!(data!)
            } else if servicename == SERVICES.addPeople {
                handler.addPeopleSuccessfull!(data!)
            } else if servicename == SERVICES.addAsset {
                handler.addAssetSuccessful!(data!)
            } else if servicename == SERVICES.getFilterData {
                handler.getFilterDataSuccessful!(data!)
            } else if servicename == SERVICES.getAssetPetList {
                handler.getAssetPetDataSuccessful!(data!)
            } else if (urlString == SERVICE_URL+SERVICES.getData) {
                if servicename == SERVICES.getLocations {
                    handler.getLocationsSuccessful!(data!)
                } else if servicename == SERVICES.getVehicals {
                    handler.getVehicalsSuccessful!(data!)
                } else {
                    handler.getDataSuccessful!(data!)
                }
            } else if (urlString == SERVICE_URL+SERVICES.getIncidents) {
                handler.getIncidentsSuccessful!(data!)
            } else if (urlString == SERVICE_URL+SERVICES.addData) {
                if servicename == SERVICES.addLocation {
                    handler.addLocationsSuccessful!(data!)
                } else if servicename == SERVICES.addVehicle {
                    handler.addVehicleSuccessful!(data!)
                }
            }
            else if (urlString == SERVICE_URL+SERVICES.updateData) {
                if servicename == SERVICES.updateLocation {
                    handler.addLocationsSuccessful!(data!)
                } else if servicename == SERVICES.updateVehicle {
                    handler.addVehicleSuccessful!(data!)
                }
            }
                
            else if (urlString == SERVICE_URL+SERVICES.addRelatedData) {
                if servicename == SERVICES.addPeople {
                    handler.addPeopleSuccessfull!(data!)
                } else if servicename == SERVICES.addAsset {
                    handler.addAssetSuccessful!(data!)
                }
            }
            else if (urlString == SERVICE_URL+SERVICES.getFilterData) {
                if servicename == SERVICES.getFilterData {
                    handler.getFilterDataSuccessful!(data!)
                }
                else if servicename == SERVICES.getAssetPetList {
                    handler.getAssetPetDataSuccessful!(data!)
                }
            }
        }
        
        task.resume()
        
    }
    
    func sendServiceJSONRequest(urlString : String, data: NSData,  handler: serviceHandlerDelegate, servicename: String = "") {
        
        
        let soapMessage = String(data: data, encoding: NSUTF8StringEncoding)
        
        print("JSONmessage \(soapMessage)")
        
        NSLog("JSONMessage %@", soapMessage!)
        
        //        let url = NSURL(string:urlString)
        let url = NSURL(string:"https://genesis.soc.texas.gov/Services/mobileService/GenericServices.asmx/GenericInput")
        
        let request = NSMutableURLRequest(URL: url!)
        
        let msgLength = String(soapMessage?.characters.count)
        
        
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("utf-8", forHTTPHeaderField: "Content-Encoding")
        //        request.addValue("application/soap+xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        //        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue(msgLength, forHTTPHeaderField: "Content-Length")
        //        request.addValue("https://genesis.soc.texas.gov/Credintials", forHTTPHeaderField: "SOAPAction")
        request.HTTPMethod = "POST"
        //        request.HTTPBody = soapMessage.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false) // or false
        request.HTTPBody = data
        request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
        
        
        let session = NSURLSession.sharedSession()
        
        let task = session.dataTaskWithRequest(request) {
            (
            let data, let response, let error) in
            
            guard let _:NSData = data, let _:NSURLResponse = response  where error == nil else {
                
                print(error)
                print("error")
                
                if(handler.error != nil) {
                    handler.error!(error!)
                }
                return
            }
            
            let dataString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print(dataString)
            
            if(urlString == SERVICE_URL+SERVICES.ping) {
                handler.pingSuccessful!(data!)
            } else if (urlString == SERVICE_URL+SERVICES.getData) {
                if servicename == SERVICES.getLocations {
                    handler.getLocationsSuccessful!(data!)
                } else if servicename == SERVICES.getVehicals {
                    handler.getVehicalsSuccessful!(data!)
                } else {
                    handler.getDataSuccessful!(data!)
                }
            } else if (urlString == SERVICE_URL+SERVICES.getIncidents) {
                handler.getIncidentsSuccessful!(data!)
            } else if (urlString == SERVICE_URL+SERVICES.addData) {
                if servicename == SERVICES.addLocation {
                    handler.addLocationsSuccessful!(data!)
                } else if servicename == SERVICES.addVehicle {
                    handler.addVehicleSuccessful!(data!)
                }
            } else if (urlString == SERVICE_URL+SERVICES.addRelatedData) {
                if servicename == SERVICES.addPeople {
                    handler.addPeopleSuccessfull!(data!)
                }
            }  
        }
        
        task.resume()
        
    }
    
}
